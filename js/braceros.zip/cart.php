<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Urban Aura - Cart</title>
<link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
<script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
<style>

.masthead {
position: relative;
background: url('assets/img/header-bg.jpg') no-repeat center center;
background-size: cover;
height: 400px;
min-height: 350px;
background-color: #000;
display: flex;
align-items: center;
justify-content: center;
text-align: center;
color: #f0c420;
font-family: 'Montserrat', sans-serif;
flex-direction: column;
padding: 0 1rem;
}
.masthead-subheading {
font-family: 'Roboto Slab', serif;
font-weight: 400;
font-size: 1.8rem;
margin-bottom: 0.3rem;
color: #f0c420;
text-shadow: 0 0 10px rgba(240,196,32,0.7);
}
.masthead-heading {
font-weight: 700;
font-size: 4rem;
text-transform: uppercase;
letter-spacing: 0.15em;
margin-bottom: 1.5rem;
color: #f0c420;
text-shadow: 0 0 20px rgba(240,196,32,0.9);
}
.btn-warning.btn-xl {
font-size: 1.5rem;
padding: 1rem 3rem;
border-radius: 3rem;
box-shadow: 0 0 15px #f0c420;
transition: box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
font-weight: 700;
letter-spacing: 0.1em;
text-transform: uppercase;
}
.btn-warning.btn-xl:hover,
.btn-warning.btn-xl:focus {
box-shadow: 0 0 30px #ffd83d, 0 0 40px #ffd83d inset;
transform: scale(1.05);
color: #000;
background-color: #f0c420;
border-color: #f0c420;
}


body {
background-color: #fff;
color: #000;
font-family: 'Roboto Slab', serif;
padding-top: 70px; 
}


  #mainNav {
      background-color: #000 !important;
    }
    #mainNav .navbar-brand,
    #mainNav .nav-link {
      color: white !important;
      font-weight: 700;
    }
    #mainNav .nav-link:hover {
      color: #ffd83d !important;
    }
    #mainNav .navbar-toggler {
      border-color: #f0c420 !important;
    }
    #mainNav .navbar-toggler-icon {
      filter: invert(99%) sepia(72%) saturate(598%) hue-rotate(357deg) brightness(99%) contrast(103%);
    }
    #mainNav {
  height: 70px;
  overflow: hidden;
}

#mainNav .navbar-brand img {
  max-height: 55px; 
  margin-top: -1px;
}

#mainNav .navbar-nav .nav-link {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}


.category-title {
font-family: 'Montserrat', sans-serif;
font-weight: 700;
font-size: 2.8rem;
margin-top: 3rem;
margin-bottom: 2rem;
text-transform: uppercase;
letter-spacing: 0.15em;
text-align: center;
color: #003366; 
position: relative;
display: inline-block;
padding-bottom: 0.5rem;

}


.product-card {
background: #f8f9fa;
border-radius: 12px;
padding: 1rem;
text-align: center;
color: #000;
box-shadow: 0 2px 8px rgba(240, 196, 32, 0.15); /* subtle gold shadow */
transition: box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
height: 100%;
display: flex;
flex-direction: column;
justify-content: space-between;
}

.product-card:hover {
box-shadow: 0 8px 25px rgba(240, 196, 32, 0.5);
transform: translateY(-5px);
}

.product-card img {
max-width: 100%;
border-radius: 8px;
margin-bottom: 1rem;
box-shadow: 0 0 10px #f0c42044;
flex-shrink: 0;
height: 180px;
object-fit: cover;
}
.product-name {
font-family: 'Montserrat', sans-serif;
font-weight: 700;
font-size: 1.25rem;
margin-bottom: 0.3rem;
color: #003366; 
}
.product-desc {
font-size: 0.9rem;
margin-bottom: 0.7rem;
color: #555;
min-height: 48px;
flex-grow: 1;
}
.product-price {
font-weight: 700;
font-size: 1.1rem;
margin-bottom: 1rem;
color: black;
}
.btn-add-cart {
background-color: #f0c420;
color: #000;
font-weight: 700;
border-radius: 2rem;
padding: 0.5rem 1.8rem;
border: none;
box-shadow: 0 0 10px #f0c420;
transition: background-color 0.3s ease, box-shadow 0.3s ease;
cursor: pointer;
align-self: center;
margin-top: auto;
}
.btn-add-cart:hover {
background-color: #ffd83d;
box-shadow: 0 0 20px #ffd83d;
color: #000;
}


.carousel-control-prev-icon,
.carousel-control-next-icon {
filter: invert(0) sepia(1) saturate(10000%) hue-rotate(35deg) brightness(1.2) contrast(1);

}


.cart-item {
display: flex;
align-items: center;
margin-bottom: 1.5rem;
padding: 1rem;
border: 1px solid #eee;
border-radius: 8px;
background-color: #fefefe;
box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.cart-item img {
width: 100px;
height: 100px;
object-fit: cover;
border-radius: 8px;
margin-right: 1.5rem;
box-shadow: 0 0 8px rgba(240, 196, 32, 0.3);
}

.cart-item-details {
flex-grow: 1;
}

.cart-item-name {
font-family: 'Montserrat', sans-serif;
font-weight: 700;
font-size: 1.3rem;
color: #003366;
margin-bottom: 0.3rem;
}

.cart-item-price {
font-weight: 600;
font-size: 1.1rem;
color: #333;
margin-bottom: 0.5rem;
}

.cart-item-quantity {
display: flex;
align-items: center;
margin-bottom: 0.5rem;
}

.cart-item-quantity input {
width: 60px;
text-align: center;
border: 1px solid #ddd;
border-radius: 5px;
padding: 0.3rem;
margin: 0 0.5rem;
}

.cart-item-quantity button {
background-color: #f0c420;
color: #000;
border: none;
border-radius: 5px;
width: 30px;
height: 30px;
font-size: 1.2rem;
display: flex;
align-items: center;
justify-content: center;
cursor: pointer;
transition: background-color 0.2s ease;
}
.cart-item-quantity button:hover {
background-color: #ffd83d;
}

.cart-item-remove {
background-color: #dc3545; 
color: #fff;
border: none;
border-radius: 5px;
padding: 0.5rem 1rem;
font-weight: 600;
cursor: pointer;
transition: background-color 0.2s ease;
}

.cart-item-remove:hover {
background-color: #c82333;
}

.cart-summary {
background-color: #f8f9fa;
border-radius: 8px;
padding: 2rem;
box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
font-size: 1.1rem;
}

.cart-summary h4 {
font-family: 'Montserrat', sans-serif;
font-weight: 700;
color: #003366;
margin-bottom: 1.5rem;
text-align: center;
}

.cart-summary .d-flex {
justify-content: space-between;
margin-bottom: 0.8rem;
}

.cart-total {
font-weight: 700;
font-size: 1.4rem;
color: #000;
border-top: 1px solid #eee;
padding-top: 1rem;
margin-top: 1.5rem;
}

.btn-checkout {
background-color: #003366; 
color: #fff;
font-weight: 700;
padding: 0.8rem 2rem;
border-radius: 2rem;
border: none;
width: 100%;
transition: background-color 0.3s ease, box-shadow 0.3s ease;
box-shadow: 0 0 10px rgba(0, 51, 102, 0.3);
}
.btn-checkout:hover {
background-color: #004085;
box-shadow: 0 0 20px rgba(0, 51, 102, 0.5);
color: #fff; 
}
</style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php" style="overflow: visible; position: relative;">
  <img src="assets/img/logo.png" alt="Urban Aura Logo" style="height: 60px; max-height: 60px; width: auto; margin-top: -10px;" />
</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
      aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      Menu
      <i class="fas fa-bars ms-1"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
        <li class="nav-item"><a class="nav-link" href="shop.php#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="regform.php">Register</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Log-in</a></li>
        <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<header class="masthead d-flex align-items-center justify-content-center">
<div class="container text-center">
<div class="masthead-subheading">Your Selections</div>
<div class="masthead-heading text-uppercase">Shopping Cart</div>
</div>
</header>

<main class="container my-5">
<h2 class="category-title text-center mb-5">Your Items</h2>

<div class="row justify-content-center">
<div class="col-lg-8">
<div class="cart-item">
<img src="top1.png" alt="Graphic Tee" />
<div class="cart-item-details">
<div class="cart-item-name">Graphic Tee</div>
<div class="cart-item-price">₱499.00</div>
<div class="cart-item-quantity">
<button type="button" class="btn btn-sm btn-minus">-</button>
<input type="text" value="1" readonly>
<button type="button" class="btn btn-sm btn-plus">+</button>
</div>
</div>
<button class="cart-item-remove">Remove</button>
</div>

<div class="cart-item">
<img src="assets/img/accessories/acc1.jpg" alt="Wristband" />
<div class="cart-item-details">
<div class="cart-item-name">Wristband</div>
<div class="cart-item-price">₱199.00</div>
<div class="cart-item-quantity">
<button type="button" class="btn btn-sm btn-minus">-</button>
<input type="text" value="2" readonly>
<button type="button" class="btn btn-sm btn-plus">+</button>
</div>
</div>
<button class="cart-item-remove">Remove</button>
</div>

<div class="cart-item">
<img src="assets/img/footwear/shoe1.jpg" alt="Sneakers" />
<div class="cart-item-details">
<div class="cart-item-name">Sneakers</div>
<div class="cart-item-price">₱1,199.00</div>
<div class="cart-item-quantity">
<button type="button" class="btn btn-sm btn-minus">-</button>
<input type="text" value="1" readonly>
<button type="button" class="btn btn-sm btn-plus">+</button>
</div>
</div>
<button class="cart-item-remove">Remove</button>
</div>

</div>

<div class="col-lg-4">
<div class="cart-summary">
<h4>Order Summary</h4>
<div class="d-flex">
<span>Subtotal:</span>
<span>₱1,897.00</span>
</div>
<div class="d-flex">
<span>Shipping:</span>
<span>₱100.00</span>
</div>
<div class="d-flex">
<span>Tax (VAT):</span>
<span>₱227.64</span>
</div>
<div class="d-flex cart-total">
<span>Total:</span>
<span>₱2,224.64</span>
</div>
<a href="checkout.php"><button class="btn btn-checkout mt-4">Proceed to Checkout</button></a>
</div>
</div>
</div>
</main>

<footer class="footer mt-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-4 text-lg-start">© Urban Aura 2025</div>
      <div class="col-lg-4 my-3 my-lg-0 text-center">
        <a class="btn btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
      </div>
      <div class="col-lg-4 text-lg-end">
        <a class="link-light text-decoration-none me-3" href="#!">Privacy Policy</a>
        <a class="link-light text-decoration-none" href="#!">Terms of Use</a>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>