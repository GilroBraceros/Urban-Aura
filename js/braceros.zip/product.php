<!DOCTYPE html> 
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Urban Aura - Shop</title>
  <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
  <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #fff;
      color: #000;
      font-family: 'Roboto Slab', serif;
      padding-top: 70px;
    }
    #mainNav {
      background-color: #000 !important;
      height: 70px;
      overflow: hidden;
      font-family: 'Montserrat', sans-serif;
    }
    #mainNav .navbar-brand,
    #mainNav .nav-link {
      color: white !important;
      font-weight: 700;
    }
    #mainNav .nav-link:hover {
      color: #ffd83d !important;
    }
    #mainNav .navbar-toggler {
      border-color: #f0c420 !important;
    }
    #mainNav .navbar-toggler-icon {
      filter: invert(99%) sepia(72%) saturate(598%) hue-rotate(357deg) brightness(99%) contrast(103%);
    }
    #mainNav .navbar-brand img {
      max-height: 55px;
      margin-top: -1px;
    }
    #mainNav .navbar-nav .nav-link {
      padding-top: 0.75rem;
      padding-bottom: 0.75rem;
    }

    .masthead {
      position: relative;
      background: url('assets/img/header-bg.jpg') no-repeat center center;
      background-size: cover;
      height: 400px;
      min-height: 350px;
      background-color: #000;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: #f0c420;
      font-family: 'Montserrat', sans-serif;
      flex-direction: column;
      padding: 0 1rem;
    }
    .masthead-subheading {
      font-family: 'Roboto Slab', serif;
      font-weight: 400;
      font-size: 1.8rem;
      margin-bottom: 0.3rem;
      color: #f0c420;
      text-shadow: 0 0 10px rgba(240,196,32,0.7);
    }
    .masthead-heading {
      font-weight: 700;
      font-size: 4rem;
      text-transform: uppercase;
      letter-spacing: 0.15em;
      margin-bottom: 1.5rem;
      color: #f0c420;
      text-shadow: 0 0 20px rgba(240,196,32,0.9);
    }
    .btn-warning.btn-xl {
      font-size: 1.5rem;
      padding: 1rem 3rem;
      border-radius: 3rem;
      box-shadow: 0 0 15px #f0c420;
      transition: box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
      font-weight: 700;
      letter-spacing: 0.1em;
      text-transform: uppercase;
    }
    .btn-warning.btn-xl:hover, 
    .btn-warning.btn-xl:focus {
      box-shadow: 0 0 30px #ffd83d, 0 0 40px #ffd83d inset;
      transform: scale(1.05);
      color: #000;
      background-color: #f0c420;
      border-color: #f0c420;
    }

    .category-title {
      font-family: 'Montserrat', sans-serif;
      font-weight: 700;
      font-size: 2.8rem;
      margin-top: 3rem;
      margin-bottom: 2rem;
      text-transform: uppercase;
      letter-spacing: 0.15em;
      text-align: center;
      color: #003366;
      position: relative;
      display: inline-block;
      padding-bottom: 0.5rem;
    }

 
    .products-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 1.8rem 1.5rem;
      padding: 0 1rem;
      max-width: 1200px;
      margin: 0 auto 4rem;
    }

    .product-card {
      background: #f8f9fa;
      border-radius: 12px;
      padding: 1rem;
      text-align: center;
      color: #000;
      box-shadow: 0 2px 8px rgba(240, 196, 32, 0.15);
      transition: box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 100%;
    }
    .product-card:hover {
      box-shadow: 0 8px 25px rgba(240, 196, 32, 0.5);
      transform: translateY(-5px);
    }
    .product-card img {
      max-width: 100%;
      border-radius: 8px;
      margin-bottom: 1rem;
      box-shadow: 0 0 10px #f0c420aa;
      height: 180px;
      object-fit: cover;
      flex-shrink: 0;
    }
    .product-name {
      font-family: 'Montserrat', sans-serif;
      font-weight: 700;
      font-size: 1.25rem;
      margin-bottom: 0.3rem;
      color: #003366;
    }
    .product-desc {
      font-size: 0.9rem;
      margin-bottom: 0.7rem;
      color: #555;
      min-height: 48px;
      flex-grow: 1;
    }
    .product-price {
      font-weight: 700;
      font-size: 1.1rem;
      margin-bottom: 1rem;
      color: black;
    }
    .btn-add-cart {
      background-color: #f0c420;
      color: #000;
      font-weight: 700;
      border-radius: 2rem;
      padding: 0.5rem 1.8rem;
      border: none;
      box-shadow: 0 0 10px #f0c420;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
      cursor: pointer;
      align-self: center;
      margin-top: auto;
    }
    .btn-add-cart:hover {
      background-color: #ffd83d;
      box-shadow: 0 0 20px #ffd83d;
      color: #000;
    }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="assets/img/logo.png" alt="Urban Aura Logo" style="height: 60px; width: auto;" />
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive">
      Menu <i class="fas fa-bars ms-1"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
        <li class="nav-item"><a class="nav-link" href="whatweoffer.php">What We Offer</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Logout</a></li>
        <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<header class="masthead d-flex align-items-center justify-content-center">
  <div class="container text-center">
    <div class="masthead-subheading">Welcome To My Website!</div>
    <div class="masthead-heading text-uppercase">Urban Aura</div>
    <a class="btn btn-warning btn-xl text-uppercase mt-4 shadow" href="#tops">Tell Me More</a>
  </div>
</header>
<main class="container">

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="category-title" id="products">Collections</h2>
    <div>
      <label for="sortSelect" class="me-2 fw-bold" style="color:#003366;">Sort by:</label>
      <select id="sortSelect" class="form-select form-select-sm" style="width: 150px;">
        <option value="newest" selected>Newest</option>
        <option value="recommended">Recommended</option>
      </select>
    </div>
  </div>

  <div class="products-grid">
    <div class="product-card">
    <img src="assets/img/top1.png" alt="Urban Vibe Hoodie" />
    <div class="product-name">Urban Vibe Hoodie</div>
    <div class="product-desc">Comfortable cotton hoodie with urban design.</div>
    <div class="product-price">₱1,299.99</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 5</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-06-01</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/tops/top2.jpg" alt="Streetwear Graphic Tee" />
    <div class="product-name">Streetwear Graphic Tee</div>
    <div class="product-desc">Printed shirt with street-style artwork.</div>
    <div class="product-price">₱599.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 4</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-05-20</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/top3.jpg" alt="Classic Denim Jacket" />
    <div class="product-name">Classic Denim Jacket</div>
    <div class="product-desc">Vintage-style denim jacket.</div>
    <div class="product-price">₱1,799.50</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 5</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-04-15</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/top4.jpg" alt="Street Print Hoodie" />
    <div class="product-name">Street Print Hoodie</div>
    <div class="product-desc">Statement hoodie with graffiti print.</div>
    <div class="product-price">₱1,399.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 3</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-06-10</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/top5.jpg" alt="Tie-Dye Oversized Shirt" />
    <div class="product-name">Tie-Dye Oversized Shirt</div>
    <div class="product-desc">Colorful tie-dye shirt for chill vibes.</div>
    <div class="product-price">₱649.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 4</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-05-28</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/top6.jpg" alt="Oversized Long Sleeve" />
    <div class="product-name">Oversized Long Sleeve</div>
    <div class="product-desc">Relaxed fit long-sleeve tee.</div>
    <div class="product-price">₱699.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 5</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-06-05</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/top7.jpg" alt="Streetwear Beanie" />
    <div class="product-name">Streetwear Beanie</div>
    <div class="product-desc">Warm knitted beanie for cold days.</div>
    <div class="product-price">₱399.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 3</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-06-03</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/top8.jpg" alt="Bucket Hat" />
    <div class="product-name">Bucket Hat</div>
    <div class="product-desc">Classic bucket hat for sunny days.</div>
    <div class="product-price">₱299.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 4</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-05-18</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/bottom1.jpg" alt="Ripped Skinny Jeans" />
    <div class="product-name">Ripped Skinny Jeans</div>
    <div class="product-desc">Dark washed ripped skinny jeans.</div>
    <div class="product-price">₱1,599.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 5</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-05-01</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/bottom2.jpg" alt="Distressed Cargo Pants" />
    <div class="product-name">Distressed Cargo Pants</div>
    <div class="product-desc">Loose fit cargo pants with utility pockets.</div>
    <div class="product-price">₱1,399.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 4</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-04-25</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/bottom3.jpg" alt="Wide-Leg Trousers" />
    <div class="product-name">Wide-Leg Trousers</div>
    <div class="product-desc">Flowy pants for relaxed urban look.</div>
    <div class="product-price">₱1,199.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 3</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-05-12</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/acc1.png" alt="Canvas Sling Bag" />
    <div class="product-name">Canvas Sling Bag</div>
    <div class="product-desc">Minimalist sling bag with secure zipper.</div>
    <div class="product-price">₱899.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 4</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-04-20</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/accessories/acc2.jpg" alt="Snapback Cap" />
    <div class="product-name">Snapback Cap</div>
    <div class="product-desc">Flat-brimmed cap with embroidered logo.</div>
    <div class="product-price">₱499.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 3</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-05-05</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/accessories/acc3.jpg" alt="Vintage Sunglasses" />
    <div class="product-name">Vintage Sunglasses</div>
    <div class="product-desc">Retro sunglasses with UV protection.</div>
    <div class="product-price">₱699.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 4</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-06-01</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/accessories/acc4.jpg" alt="Urban Crossbody Bag" />
    <div class="product-name">Urban Crossbody Bag</div>
    <div class="product-desc">Small crossbody bag with durable strap.</div>
    <div class="product-price">₱999.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 5</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-05-22</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/outerwear1.jpg" alt="Puffer Vest" />
    <div class="product-name">Puffer Vest</div>
    <div class="product-desc">Lightweight insulated vest.</div>
    <div class="product-price">₱1,099.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 4</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-06-07</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

  <div class="product-card">
    <img src="assets/img/outerwear2.jpg" alt="Techwear Jacket" />
    <div class="product-name">Techwear Jacket</div>
    <div class="product-desc">Futuristic jacket with zippers and straps.</div>
    <div class="product-price">₱2,899.00</div>
    <div class="product-rating" style="font-weight: 700; margin-bottom: 0.2rem;">Rating: 5</div>
    <div class="product-date" style="font-size: 0.85rem; color: #555; margin-bottom: 1rem;">Added on: 2025-06-12</div>
    <button class="btn-add-cart">Add to Cart</button>
  </div>

</div>



</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
