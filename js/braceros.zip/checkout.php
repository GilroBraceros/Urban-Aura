<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Checkout - Urban Aura</title>
  <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
  <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #fff;
      color: #000;
      font-family: 'Roboto Slab', serif;
      padding-top: 70px;
    }
    #mainNav {
      background-color: #000 !important;
      height: 70px;
      overflow: hidden;
      font-family: 'Montserrat', sans-serif;
    }
    #mainNav .navbar-brand,
    #mainNav .nav-link {
      color: white !important;
      font-weight: 700;
    }
    #mainNav .nav-link:hover {
      color: #ffd83d !important;
    }
    #mainNav .navbar-toggler {
      border-color: #f0c420 !important;
    }
    #mainNav .navbar-toggler-icon {
      filter: invert(99%) sepia(72%) saturate(598%) hue-rotate(357deg) brightness(99%) contrast(103%);
    }
    #mainNav .navbar-brand img {
      max-height: 55px;
      margin-top: -1px;
    }
    #mainNav .navbar-nav .nav-link {
      padding-top: 0.75rem;
      padding-bottom: 0.75rem;
    }
    .section-title {
      font-family: 'Montserrat', sans-serif;
      font-size: 2.5rem;
      font-weight: 700;
      text-align: center;
      margin-bottom: 2rem;
      color: #003366;
      border-bottom: 3px solid #f0c420;
      display: inline-block;
      padding-bottom: 0.3rem;
    }
    .form-control:focus {
      border-color: #f0c420;
      box-shadow: 0 0 5px #f0c420;
    }
    .btn-checkout {
      background-color: #f0c420;
      color: #000;
      font-weight: 700;
      border-radius: 2rem;
      padding: 0.75rem 2rem;
      border: none;
      box-shadow: 0 0 10px #f0c420;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
    }
    .btn-checkout:hover {
      background-color: #ffd83d;
      box-shadow: 0 0 20px #ffd83d;
      color: #000;
    }
    .order-summary {
      background: #f8f9fa;
      padding: 1.5rem;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(240, 196, 32, 0.2);
    }
    .order-summary h5 {
      border-bottom: 2px solid #f0c420;
      padding-bottom: 0.5rem;
      margin-bottom: 1rem;
      font-weight: 700;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php" style="overflow: visible; position: relative;">
      <img src="assets/img/logo.png" alt="Urban Aura Logo" style="height: 60px; max-height: 60px; width: auto; margin-top: -10px;" />
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
      aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      Menu
      <i class="fas fa-bars ms-1"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
        <li class="nav-item"><a class="nav-link" href="shop.php#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="regform.php">Register</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Log-in</a></li>
        <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container my-5">
  <h2 class="section-title">Checkout</h2>
  <form method="POST" action="place_order.php">
    <div class="row g-4">
      <div class="col-md-6">
        <h5 class="mb-3">Customer Information</h5>
        <div class="mb-3">
          <label for="fullname" class="form-label">Full Name</label>
          <input type="text" class="form-control" id="fullname" name="fullname" required />
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email Address</label>
          <input type="email" class="form-control" id="email" name="email" required />
        </div>
        <div class="mb-3">
          <label for="phone" class="form-label">Phone Number</label>
          <input type="tel" class="form-control" id="phone" name="phone" required />
        </div>
      </div>
      <div class="col-md-6">
        <h5 class="mb-3">Shipping Address</h5>
        <div class="mb-3">
          <label for="address" class="form-label">Street Address</label>
          <input type="text" class="form-control" id="address" name="address" required />
        </div>
        <div class="mb-3">
          <label for="city" class="form-label">City</label>
          <input type="text" class="form-control" id="city" name="city" required />
        </div>
        <div class="mb-3">
          <label for="province" class="form-label">Province</label>
          <input type="text" class="form-control" id="province" name="province" required />
        </div>
        <div class="mb-3">
          <label for="zipcode" class="form-label">ZIP Code</label>
          <input type="text" class="form-control" id="zipcode" name="zipcode" required />
        </div>
      </div>
      <div class="col-md-6">
        <h5 class="mb-3">Payment Method</h5>
        <div class="form-check mb-2">
          <input class="form-check-input" type="radio" name="payment_method" id="creditcard" value="Credit Card" required />
          <label class="form-check-label" for="creditcard">Credit Card</label>
        </div>
        <div class="form-check mb-2">
          <input class="form-check-input" type="radio" name="payment_method" id="paypal" value="PayPal" />
          <label class="form-check-label" for="paypal">PayPal</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="payment_method" id="cod" value="Cash on Delivery" />
          <label class="form-check-label" for="cod">Cash on Delivery</label>
        </div>
      </div>
      <div class="col-md-6">
        <div class="order-summary">
          <h5>Order Summary</h5>
          <p><strong>Items:</strong> 2 Products</p>
          <p><strong>Total:</strong> ₱1,398.00</p>
        </div>
      </div>
    </div>
    <div class="text-center mt-5">
      <button type="submit" class="btn btn-checkout btn-xl">Place Order</button>
    </div>
  </form>
</div>

<footer class="footer mt-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-4 text-lg-start">© Urban Aura 2025</div>
      <div class="col-lg-4 my-3 my-lg-0 text-center">
        <a class="btn btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
      </div>
      <div class="col-lg-4 text-lg-end">
        <a class="link-light text-decoration-none me-3" href="#!">Privacy Policy</a>
        <a class="link-light text-decoration-none" href="#!">Terms of Use</a>
      </div>
    </div>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
