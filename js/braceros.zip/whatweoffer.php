<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>What We Offer - Urban Aura</title>
  <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
  <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #fff;
      color: #000;
      font-family: 'Roboto Slab', serif;
      padding-top: 70px;
    }
    #mainNav {
      background-color: #000 !important;
      height: 70px;
      overflow: hidden;
      font-family: 'Montserrat', sans-serif;
    }
    #mainNav .navbar-brand,
    #mainNav .nav-link {
      color: white !important;
      font-weight: 700;
    }
    #mainNav .nav-link:hover {
      color: #ffd83d !important;
    }
    #mainNav .navbar-toggler {
      border-color: #f0c420 !important;
    }
    #mainNav .navbar-toggler-icon {
      filter: invert(99%) sepia(72%) saturate(598%) hue-rotate(357deg) brightness(99%) contrast(103%);
    }
    #mainNav .navbar-brand img {
      max-height: 55px;
      margin-top: -1px;
    }
    #mainNav .navbar-nav .nav-link {
      padding-top: 0.75rem;
      padding-bottom: 0.75rem;
    }
    .section-title {
      font-family: 'Montserrat', sans-serif;
      font-size: 2.5rem;
      font-weight: 700;
      text-align: center;
      margin-bottom: 2rem;
      color: #003366;
      border-bottom: 3px solid #f0c420;
      display: inline-block;
      padding-bottom: 0.3rem;
    }
    .sort-select {
      max-width: 200px;
      font-weight: 600;
      border: 2px solid #f0c420;
      border-radius: 8px;
      color: #000;
    }
    .product-card {
      background: #f8f9fa;
      border-radius: 12px;
      padding: 1rem;
      text-align: center;
      box-shadow: 0 2px 8px rgba(240, 196, 32, 0.15);
      transition: box-shadow 0.3s ease, transform 0.3s ease;
    }
    .product-card:hover {
      box-shadow: 0 8px 25px rgba(240, 196, 32, 0.4);
      transform: translateY(-5px);
    }
    .product-card img {
      max-width: 100%;
      border-radius: 8px;
      margin-bottom: 1rem;
      height: 180px;
      object-fit: cover;
    }
    .product-name {
      font-family: 'Montserrat', sans-serif;
      font-weight: 700;
      font-size: 1.25rem;
      margin-bottom: 0.3rem;
      color: #003366;
    }
    .product-price {
      font-weight: 700;
      font-size: 1.1rem;
      color: #000;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="assets/img/logo.png" alt="Urban Aura Logo" style="height: 60px; width: auto;" />
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive">
      Menu <i class="fas fa-bars ms-1"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
        <li class="nav-item"><a class="nav-link" href="shop.php">Shop</a></li>
        <li class="nav-item"><a class="nav-link" href="regform.php">Register</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Log-in</a></li>
        <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container my-5">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="section-title">What We Offer</h2>
    <select class="form-select sort-select" aria-label="Sort By">
      <option selected>Sort By</option>
      <option value="newest">Newest</option>
      <option value="cheapest">Cheapest</option>
      <option value="recommended">Most Recommended</option>
    </select>
  </div>

  <div class="row g-4">
    <div class="col-md-4 col-sm-6">
      <div class="product-card">
        <img src="assets/img/top1.png" alt="Graphic Tee">
        <div class="product-name">Graphic Tee</div>
        <div class="product-price">₱499.00</div>
      </div>
    </div>
    <div class="col-md-4 col-sm-6">
      <div class="product-card">
        <img src="assets/img/tops/top2.jpg" alt="Hoodie">
        <div class="product-name">Hoodie</div>
        <div class="product-price">₱899.00</div>
      </div>
    </div>
    <div class="col-md-4 col-sm-6">
      <div class="product-card">
        <img src="assets/img/accessories/acc2.jpg" alt="Cap">
        <div class="product-name">Cap</div>
        <div class="product-price">₱299.00</div>
      </div>
    </div>
    <div class="col-md-4 col-sm-6">
      <div class="product-card">
        <img src="assets/img/shoe1.png" alt="Sneakers">
        <div class="product-name">Sneakers</div>
        <div class="product-price">₱1,199.00</div>
      </div>
    </div>
    <div class="col-md-4 col-sm-6">
      <div class="product-card">
        <img src="assets/img/footwear/shoe2.jpg" alt="Boots">
        <div class="product-name">Boots</div>
        <div class="product-price">₱1,499.00</div>
      </div>
    </div>
    <div class="col-md-4 col-sm-6">
      <div class="product-card">
        <img src="assets/img/acc.png" alt="Wristband">
        <div class="product-name">Wristband</div>
        <div class="product-price">₱199.00</div>
      </div>
    </div>
  </div>
</div>

<footer class="footer mt-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-4 text-lg-start">© Urban Aura 2025</div>
      <div class="col-lg-4 my-3 my-lg-0 text-center">
        <a class="btn btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
      </div>
      <div class="col-lg-4 text-lg-end">
        <a class="link-light text-decoration-none me-3" href="#!">Privacy Policy</a>
        <a class="link-light text-decoration-none" href="#!">Terms of Use</a>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
