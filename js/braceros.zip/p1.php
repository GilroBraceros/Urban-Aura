<!DOCTYPE html> 
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Urban Aura - Product Detail</title>
<link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
<script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" />
<link href="css/styles.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
<style>

.masthead {
position: relative;
background: url('assets/img/header-bg.jpg') no-repeat center center;
background-size: cover;
height: 400px;
min-height: 350px;
background-color: #000;
display: flex;
align-items: center;
justify-content: center;
text-align: center;
color: #f0c420;
font-family: 'Montserrat', sans-serif;
flex-direction: column;
padding: 0 1rem;
}

.masthead.product-detail-masthead {
height: 250px; 
min-height: 200px;
}
.masthead.product-detail-masthead .masthead-subheading {
font-size: 1.5rem;
margin-bottom: 0.1rem;
}
.masthead.product-detail-masthead .masthead-heading {
font-size: 3rem;
margin-bottom: 0;
}

.masthead-subheading {
font-family: 'Roboto Slab', serif;
font-weight: 400;
font-size: 1.8rem;
margin-bottom: 0.3rem;
color: #f0c420;
text-shadow: 0 0 10px rgba(240,196,32,0.7);
}
.masthead-heading {
font-weight: 700;
font-size: 4rem;
text-transform: uppercase;
letter-spacing: 0.15em;
margin-bottom: 1.5rem;
color: #f0c420;
text-shadow: 0 0 20px rgba(240,196,32,0.9);
}
.btn-warning.btn-xl {
font-size: 1.5rem;
padding: 1rem 3rem;
border-radius: 3rem;
box-shadow: 0 0 15px #f0c420;
transition: box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
font-weight: 700;
letter-spacing: 0.1em;
text-transform: uppercase;
}
.btn-warning.btn-xl:hover,
.btn-warning.btn-xl:focus {
box-shadow: 0 0 30px #ffd83d, 0 0 40px #ffd83d inset;
transform: scale(1.05);
color: #000;
background-color: #f0c420;
border-color: #f0c420;
}

/* Body with white bg and black text */
body {
background-color: #fff;
color: #000;
font-family: 'Roboto Slab', serif;
padding-top: 70px; /* for fixed navbar */
}

/* Navbar brand and links - WHITE text on black navbar */
#mainNav {
background-color: #000 !important;
}
#mainNav .navbar-brand,
#mainNav .nav-link {
color: #fff !important; /* Changed from gold to white */
font-weight: 700;
}
#mainNav .nav-link:hover {
color: #ffd83d !important; /* Gold on hover */
}
#mainNav .navbar-toggler {
border-color: #f0c420 !important;
}
#mainNav .navbar-toggler-icon {
filter: invert(99%) sepia(72%) saturate(598%) hue-rotate(357deg) brightness(99%) contrast(103%);
}

/* Category Titles (can be reused if needed, but not primary for detail page) */
.category-title {
font-family: 'Montserrat', sans-serif;
font-weight: 700;
font-size: 2.8rem;
margin-top: 3rem;
margin-bottom: 2rem;
text-transform: uppercase;
letter-spacing: 0.15em;
text-align: center;
color: #003366; /* navy blue for contrast */
position: relative;
display: inline-block;
padding-bottom: 0.5rem;
}

/* --- Product Detail Specific Styles --- */
.product-detail-section {
background-color: #fefefe;
padding: 3rem;
border-radius: 12px;
box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
margin-top: 3rem;
}

.product-detail-image {
max-width: 100%;
height: auto;
border-radius: 10px;
box-shadow: 0 5px 15px rgba(240, 196, 32, 0.3);
transition: transform 0.3s ease;
}
.product-detail-image:hover {
transform: scale(1.02);
}

.product-detail-name {
font-family: 'Montserrat', sans-serif;
font-weight: 700;
font-size: 2.5rem;
color: #003366;
margin-bottom: 1rem;
line-height: 1.2;
}

.product-detail-price {
font-weight: 700;
font-size: 2rem;
color: black;
margin-bottom: 1.5rem;
}

.product-detail-description {
font-size: 1.1rem;
color: #444;
line-height: 1.7;
margin-bottom: 2rem;
}

.product-detail-features ul {
list-style: none;
padding-left: 0;
margin-bottom: 1.5rem;
}

.product-detail-features ul li {
margin-bottom: 0.7rem;
color: #333;
font-size: 1rem;
}

.product-detail-features ul li i {
color: #f0c420; /* Gold icon */
margin-right: 0.8rem;
}

.btn-add-to-cart-detail {
background-color: #f0c420;
color: #000;
font-weight: 700;
border-radius: 2.5rem;
padding: 0.8rem 3rem;
border: none;
font-size: 1.3rem;
box-shadow: 0 0 15px #f0c420;
transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
cursor: pointer;
text-transform: uppercase;
letter-spacing: 0.05em;
}
.btn-add-to-cart-detail:hover {
background-color: #ffd83d;
box-shadow: 0 0 25px #ffd83d;
transform: translateY(-2px);
color: #000;
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php" style="overflow: visible; position: relative;">
      <img src="assets/img/logo.png" alt="Urban Aura Logo" style="height: 60px; max-height: 60px; width: auto; margin-top: -10px;" />
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
      aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      Menu
      <i class="fas fa-bars ms-1"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
        <li class="nav-item"><a class="nav-link" href="shop.php#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="shop.html#about">About us</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Log-in</a></li>
        <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<main class="container my-5">
  <div class="row product-detail-section">
    <div class="col-lg-6 mb-4 mb-lg-0 d-flex justify-content-center align-items-center">
      <img class="product-detail-image" src="assets/img/top1.png" alt="Urban Vibe Hoodie">
    </div>
    <div class="col-lg-6">
      <h2 class="product-detail-name">Urban Vibe Hoodie</h2>
      <div class="product-detail-price">₱1,299.99</div>
      <div class="product-detail-description">
        Comfortable cotton hoodie with urban design. Perfect for casual wear and street style.
      </div>
      <div class="product-detail-features mb-4">
        <h6>Key Features:</h6>
        <ul>
          <li><i class="fas fa-check-circle"></i> Material: 100% Cotton</li>
          <li><i class="fas fa-check-circle"></i> Fit: Relaxed Fit</li>
          <li><i class="fas fa-check-circle"></i> Design: Urban inspired graphics</li>
          <li><i class="fas fa-check-circle"></i> Care: Machine Wash Cold</li>
          <li><i class="fas fa-check-circle"></i> Sizes: S, M, L, XL, XXL</li>
          <li><i class="fas fa-check-circle"></i> Colors: Black, Grey, Navy</li>
        </ul>
      </div>
      <button class="btn btn-warning btn-add-to-cart-detail">Add to Cart</button>
    </div>
  </div>
</main>

<footer class="footer mt-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-4 text-lg-start">© Urban Aura 2025</div>
      <div class="col-lg-4 my-3 my-lg-0 text-center">
        <a class="btn btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a class="btn btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
      </div>
      <div class="col-lg-4 text-lg-end">
        <a class="link-light text-decoration-none me-3" href="#!">Privacy Policy</a>
        <a class="link-light text-decoration-none" href="#!">Terms of Use</a>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
